"""Let's Find Some podcasts!"""

__version__ = "0.1.0"

def search(name, count=5):
    """Search podcast by name."""
    raise NotImplementedError()

